create function f_generar_correlativo(p_tabla character varying) returns SETOF integer
  language plpgsql
as
$$
declare p_tabla alias for $1;
	
	begin
		return query
		select 
			c.numero+1 
		from 
			correlativo c 
		where c.tabla = p_tabla;
	end

$$;

alter function f_generar_correlativo(varchar) owner to postgres;

